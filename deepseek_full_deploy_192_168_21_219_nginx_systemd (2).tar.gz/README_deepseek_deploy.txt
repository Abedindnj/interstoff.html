
Deployment package for Deepseek sync backend + frontend (configured for server IP 192.168.21.219)

Quick start (requires Docker & docker-compose):
1. Copy the zip contents to the server 192.168.21.219, e.g. /opt/deepseek
2. On the server, run:
   - docker compose up --build -d
   (or: docker-compose up --build -d)
3. The backend will be available at: http://192.168.21.219:3000
4. First-time: register a user:
   curl -X POST http://192.168.21.219:3000/auth/register -H "Content-Type: application/json" -d '{"username":"admin","password":"yourpass"}'
5. Login to obtain JWT:
   curl -X POST http://192.168.21.219:3000/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"yourpass"}'
   => store the token and use in frontend (it saves token in localStorage when using provided login modal)
6. Use the frontend file deepseek_html_20251104_240020_modified_v4.html in your app (it is pre-configured to talk to http://192.168.21.219:3000).

Database credentials (Postgres):
 - host (internal in docker-compose): db
 - port: 5432
 - user: postgres
 - password: 1234
 - database: deepseek_db

JWT secret used (keep secret, rotate as needed):
replace_this_with_a_strong_secret

If you want me to:
 - Inline the frontend_real_auth_snippet.js into the HTML,
 - Create systemd service for running with Docker,
 - Or produce a MongoDB variant,
tell me and I will update the package.


=== NGINX + HTTPS (self-signed) Setup ===

1. On the server (192.168.21.219), install nginx and openssl:
   sudo apt update
   sudo apt install nginx openssl -y

2. Generate a self-signed certificate (script provided):
   sudo bash ./generate_selfsigned.sh
   # This places cert/key at /etc/ssl/certs/deepseek_selfsigned.crt and /etc/ssl/private/deepseek_selfsigned.key

3. Copy the nginx config to /etc/nginx/sites-available/deepseek
   sudo cp ./nginx_deepseek.conf /etc/nginx/sites-available/deepseek
   sudo ln -s /etc/nginx/sites-available/deepseek /etc/nginx/sites-enabled/deepseek

4. Reload nginx:
   sudo nginx -t
   sudo systemctl reload nginx

After this, https://192.168.21.219 should proxy to the backend (note: browser will warn about self-signed cert).


=== Systemd Service ===

A systemd unit file 'deepseek.service' is provided. To use it:
sudo cp ./deepseek.service /etc/systemd/system/deepseek.service
sudo systemctl daemon-reload
sudo systemctl enable deepseek.service
sudo systemctl start deepseek.service
Check status: sudo systemctl status deepseek.service
This will run 'docker compose up -d --build' at boot and bring down on stop.
