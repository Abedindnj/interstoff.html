#!/bin/bash
# generate_selfsigned.sh
# Generates a self-signed cert for deepseek and places it in /etc/ssl (requires sudo)
set -e
CRT_PATH=/etc/ssl/certs/deepseek_selfsigned.crt
KEY_PATH=/etc/ssl/private/deepseek_selfsigned.key

sudo mkdir -p /etc/ssl/private
sudo openssl req -x509 -nodes -days 3650 -newkey rsa:2048 \
  -keyout "$KEY_PATH" -out "$CRT_PATH" \
  -subj "/C=BD/ST=Dhaka/L=Dhaka/O=Deepseek/OU=IT/CN=192.168.21.219"

sudo chmod 644 "$CRT_PATH"
sudo chmod 600 "$KEY_PATH"

echo "Self-signed certificate generated:"
echo "  cert: $CRT_PATH"
echo "  key:  $KEY_PATH"
