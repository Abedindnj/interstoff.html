// server.js - Node/Express + PostgreSQL + JWT auth
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());

// Postgres pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Simple helper
async function query(text, params){ return pool.query(text, params); }

// Ensure tables exist (basic)
async function initDB(){
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT now()
    );
  `);
  await query(`
    CREATE TABLE IF NOT EXISTS sync_logs (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      payload JSONB,
      created_at TIMESTAMPTZ DEFAULT now()
    );
  `);
  console.log('DB initialized');
}
initDB().catch(err=>console.error('initDB error', err));

// Auth: register (use only for initial setup; can disable in production)
app.post('/auth/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({error:'username & password required'});
    const hash = await bcrypt.hash(password, 12);
    const r = await query('INSERT INTO users (username, password_hash) VALUES ($1,$2) RETURNING id, username, created_at', [username, hash]);
    res.json({ok:true, user: r.rows[0]});
  } catch (e) {
    console.error(e);
    if (e.code === '23505') return res.status(409).json({error:'username exists'});
    res.status(500).json({error:'server error'});
  }
});

// Auth: login -> returns JWT
app.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({error:'username & password required'});
    const r = await query('SELECT id, username, password_hash FROM users WHERE username=$1', [username]);
    if (r.rowCount === 0) return res.status(401).json({error:'invalid credentials'});
    const user = r.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({error:'invalid credentials'});
    const token = jwt.sign({ sub: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1h' });
    res.json({ok:true, token});
  } catch (e) {
    console.error('login error', e);
    res.status(500).json({error:'server error'});
  }
});

// Middleware: verify JWT
function requireAuth(req, res, next){
  const auth = req.headers['authorization'] || '';
  if (!auth.startsWith('Bearer ')) return res.status(401).json({error:'missing token'});
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({error:'invalid token'});
  }
}

// Protected sync route
app.post('/api/sync', requireAuth, async (req, res) => {
  try {
    const payload = req.body;
    // Basic validation
    if (!payload) return res.status(400).json({error:'no payload'});
    // store log
    await query('INSERT INTO sync_logs (user_id, payload) VALUES ($1,$2)', [req.user.sub, payload]);
    res.json({ok:true, message:'synced', received: Array.isArray(payload.productionData) ? payload.productionData.length : 1});
  } catch (e) {
    console.error('sync error', e);
    res.status(500).json({error:'server error'});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server listening on', port));