/* FRONTEND: Replace demo login with real backend calls.
   Usage: set serverUrl element textContent to backend base URL, e.g. http://localhost:3000
*/
async function realLogin(username, password) {
  const url = (document.getElementById('serverUrl') ? document.getElementById('serverUrl').textContent.trim() : 'http://localhost:3000');
  const res = await fetch(url + '/auth/login', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({username, password})
  });
  const j = await res.json();
  if (!res.ok) {
    throw new Error(j.error || 'Login failed');
  }
  // store JWT
  localStorage.setItem('deepseek_jwt', j.token);
  return j.token;
}

async function realSyncToServer() {
  const url = (document.getElementById('serverUrl') ? document.getElementById('serverUrl').textContent.trim() : 'http://localhost:3000');
  const token = localStorage.getItem('deepseek_jwt');
  if (!token) throw new Error('Not logged in');
  const payload = { productionData: window.productionData || [], timestamp: new Date().toISOString() };
  const res = await fetch(url + '/api/sync', {
    method: 'POST',
    headers: {'Content-Type':'application/json', 'Authorization':'Bearer ' + token},
    body: JSON.stringify(payload)
  });
  return res.json();
}