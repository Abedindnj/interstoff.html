-- migration.sql: create tables (if not using initDB)
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sync_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  payload JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);